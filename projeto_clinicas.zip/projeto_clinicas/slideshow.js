	// Declaração de variáveis

	var i = 0;
	var imagens = [];
	var tempo = 3000;

	// Lista de Imagens

	imagens[0] = 'medicos.jpg';
	imagens[1] = 'medicos2.jpg';
	imagens[2] = 'medicos3.jpg';
	imagens[3] = 'medicos4.jpeg';
	imagens[4] = 'medicos5.jpg';
	imagens[5] = 'medicos6.png';
	imagens[6] = 'medicos7.png';

	// Mudar imagens

	function mudarImagem(){

		document.slide.src = imagens[i];

		if(i < imagens.length - 1){
			i++;

		}else{
			i = 0;

		}

		setTimeout("mudarImagem()" , tempo);
	}

	window.onload = mudarImagem;


